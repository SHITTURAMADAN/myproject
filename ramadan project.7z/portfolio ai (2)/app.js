
const a= 'ohdrweulirasoifsa ;foiasdifaosjf;asdklf'


// let hint = document.getElementsByClassName('hint')


// hint.addEventListener('click', function() {
//     hint.textContent = 'Hello, this is the text that appears when you click the button!';
// });

// Select all elements with the class name 'hint'
let hints = document.getElementsByClassName('hint');

// Loop through each element and add an event listener
for (let i = 0; i < hints.length; i++) {
    // Store the original text content in a data attribute
    hints[i].setAttribute('data-original-text', hints[i].textContent);

    hints[i].addEventListener('click', function() {
        // Change the text content of the clicked element
        hints[i].textContent = 'Hello, the hint is a sport game!';
        
        // After 10 seconds, revert to the original text
        setTimeout(function() {
            hints[i].textContent = hints[i].getAttribute('data-original-text');
        }, 1000); // 10000 milliseconds = 10 seconds
    })};

const secretWords = ['football', 'basketball', 'baseball', 'hockey', 'tennis'];
userWord= document.getElementById('inpt');
userWord.maxLength=15;
btn= document.getElementById('btn');

answer= document.getElementById('answer');


btn.addEventListener('click', function() {
    // Get the value from the input field and trim any extra whitespace
    const userInput = userWord.value.trim().toLowerCase();

    // Check if the user input is in the list of secret words
    if (secretWords.includes(userInput)) {
        answer.textContent = 'Correct!';
        answer.style.color = 'green'; // Optional: change color for correct answer
    } else {
        answer.textContent = 'Wrong!';
        answer.style.color = 'red'; // Optional: change color for wrong answer
    }

    // Optionally, clear the input field after checking
    userWord.value = '';
});
