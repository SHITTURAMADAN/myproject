# a progam that ask middlename, favourite_pasta, number, symbol. combine this into one password.
print()
print('STRONG PASSWORD RECOMMENDATION APP')
print()

middlename=input('ENTER YOUR MIDDLENAME :')
paster=input('ENTER YOUR FAVOURITE PASTA :')
number=input('ENTER YOUR phone number :')
symbol=input('ENTER a symbol :')

                                                                                                                                      
print('HERE IS A SUGGESTED STRONG PASSWORD')


strong_password= middlename + paster +number+symbol

print(strong_password) 

# Create a canvas to place the background image
canvas = tk.Canvas(root, width=400, height=400)
canvas.pack(fill="both", expand=True)