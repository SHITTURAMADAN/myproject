import random
import string

def generate_strong_password(middlename, pasta, phone_number, symbol):
    # Create a base for the password
    password_elements = [
        middlename,
        pasta,
        phone_number,
        symbol,
        random.choice(string.ascii_uppercase),  # Random uppercase letter
        random.choice(string.ascii_lowercase),  # Random lowercase letter
        random.choice(string.digits),            # Random digit
        random.choice(string.punctuation)       # Random special character
    ]
    
    # Ensure a minimum length and mix in random characters
    while len(password_elements) < 12:  # Minimum password length
        password_elements.append(random.choice(
            string.ascii_letters + string.digits + string.punctuation))
    
    # Shuffle the elements to make the password less predictable
    random.shuffle(password_elements)
    
    # Join the elements to form the final password
    return ''.join(password_elements)

print()
print('STRONG PASSWORD RECOMMENDATION APP')
print()

# Gather user input
middlename = input('ENTER YOUR MIDDLENAME: ')
pasta = input('ENTER YOUR FAVOURITE PASTA: ')
phone_number = input('ENTER YOUR PHONE NUMBER: ')
symbol = input('ENTER A SYMBOL: ')

# Generate a strong password
strong_password = generate_strong_password(middlename, pasta, phone_number, symbol)

print('HERE IS A SUGGESTED STRONG PASSWORD:')
print(strong_password)
