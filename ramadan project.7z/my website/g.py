import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk  # For handling images in Tkinter
import random
import string

# Password Generation Function
def generate_password():
    length = length_slider.get()
    use_uppercase = uppercase_var.get()
    use_lowercase = lowercase_var.get()
    use_numbers = numbers_var.get()
    use_symbols = symbols_var.get()
    
    password = generate_password_logic(length, use_uppercase, use_lowercase, use_numbers, use_symbols)
    password_var.set(password)
    update_strength(password)

def generate_password_logic(length, use_uppercase, use_lowercase, use_numbers, use_symbols):
    characters = ""
    if use_uppercase:
        characters += string.ascii_uppercase
    if use_lowercase:
        characters += string.ascii_lowercase
    if use_numbers:
        characters += string.digits
    if use_symbols:
        characters += string.punctuation
    
    if not characters:
        messagebox.showerror("Error", "Please select at least one option")
        return ""
    
    return ''.join(random.choice(characters) for _ in range(length))

def update_strength(password):
    strength = "Weak"
    if len(password) >= 12 and any(c in string.punctuation for c in password):
        strength = "Strong"
    elif len(password) >= 8:
        strength = "Medium"
    strength_label.config(text=f"Strength: {strength}")

# Main Tkinter window
root = tk.Tk()
root.title("Password Generator")
root.geometry("400x400")  # Set the window size

# Load the background image
image_path = "blurred_image.png"  # Replace with the path to your image
bg_image = Image.open(image_path)
bg_image = bg_image.resize((400, 400), Image.LANCZOS)  # Resize to fit the window size
bg_image_tk = ImageTk.PhotoImage(bg_image)

# Create a canvas to place the background image
canvas = tk.Canvas(root, width=400, height=400)
canvas.pack(fill="both", expand=True)

# Store the reference to the image
canvas.bg_image = bg_image_tk  # Keep a reference to avoid garbage collection

# Display the background image on the canvas
canvas.create_image(0, 0, image=canvas.bg_image, anchor="nw")

#root = tk.Tk()
root.title("Password Generator")
root.geometry("400x400")  # Set the window size
root.resizable(False, False)  # Disable window resizing


# Display the background image on the canvas
canvas.create_image(0, 0, image=bg_image_tk, anchor="nw")

# Password Display
password_var = tk.StringVar()
password_entry = tk.Entry(root, textvariable=password_var, font=("Helvetica", 14), width=30)
canvas.create_window(200, 50, window=password_entry)  # Positioning on canvas

# Character Length Label
length_label = tk.Label(root, text="Character Length:")
canvas.create_window(200, 100, window=length_label)

# Character Length Slider
length_slider = tk.Scale(root, from_=4, to_=32, orient="horizontal")
length_slider.set(10)
canvas.create_window(200, 130, window=length_slider)

# Checkboxes for options
uppercase_var = tk.BooleanVar(value=True)
lowercase_var = tk.BooleanVar(value=True)
numbers_var = tk.BooleanVar(value=True)
symbols_var = tk.BooleanVar(value=False)

uppercase_checkbox = tk.Checkbutton(root, text="Include Uppercase Letters", variable=uppercase_var)
canvas.create_window(200, 160, window=uppercase_checkbox)

lowercase_checkbox = tk.Checkbutton(root, text="Include Lowercase Letters", variable=lowercase_var)
canvas.create_window(200, 190, window=lowercase_checkbox)

numbers_checkbox = tk.Checkbutton(root, text="Include Numbers", variable=numbers_var)
canvas.create_window(200, 220, window=numbers_checkbox)

symbols_checkbox = tk.Checkbutton(root, text="Include Symbols", variable=symbols_var)
canvas.create_window(200, 250, window=symbols_checkbox)

# Strength Display
strength_label = tk.Label(root, text="Strength: Weak")
canvas.create_window(200, 280, window=strength_label)

# Generate Button
generate_button = tk.Button(root, text="Generate Password", command=generate_password)
canvas.create_window(200, 320, window=generate_button)

root.mainloop()
