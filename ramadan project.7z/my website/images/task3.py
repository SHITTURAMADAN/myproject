import tkinter as tk
from tkinter import messagebox
import random
import string

# Password Generation Function
def generate_password():
    length = length_slider.get()
    use_uppercase = uppercase_var.get()
    use_lowercase = lowercase_var.get()
    use_numbers = numbers_var.get()
    use_symbols = symbols_var.get()
    
    password = generate_password_logic(length, use_uppercase, use_lowercase, use_numbers, use_symbols)
    password_var.set(password)
    update_strength(password)

def generate_password_logic(length, use_uppercase, use_lowercase, use_numbers, use_symbols):
    characters = ""
    if use_uppercase:
        characters += string.ascii_uppercase
    if use_lowercase:
        characters += string.ascii_lowercase
    if use_numbers:
        characters += string.digits
    if use_symbols:
        characters += string.punctuation
    
    if not characters:
        messagebox.showerror("Error", "Please select at least one option")
        return ""
    
    return ''.join(random.choice(characters) for _ in range(length))

def update_strength(password):
    strength = "Weak"
    if len(password) >= 12 and any(c in string.punctuation for c in password):
        strength = "Strong"
    elif len(password) >= 8:
        strength = "Medium"
    strength_label.config(text=f"Strength: {strength}")

# Main Tkinter window
root = tk.Tk()
root.title("Password Generator")

# Password Display
password_var = tk.StringVar()
tk.Entry(root, textvariable=password_var, font=("Helvetica", 14), width=30).pack(pady=10)

# Character Length
tk.Label(root, text="Character Length:").pack()
length_slider = tk.Scale(root, from_=4, to_=32, orient="horizontal")
length_slider.set(10)
length_slider.pack()

# Checkboxes for options
uppercase_var = tk.BooleanVar(value=True)
lowercase_var = tk.BooleanVar(value=True)
numbers_var = tk.BooleanVar(value=True)
symbols_var = tk.BooleanVar(value=False)

tk.Checkbutton(root, text="Include Uppercase Letters", variable=uppercase_var).pack(anchor='w')
tk.Checkbutton(root, text="Include Lowercase Letters", variable=lowercase_var).pack(anchor='w')
tk.Checkbutton(root, text="Include Numbers", variable=numbers_var).pack(anchor='w')
tk.Checkbutton(root, text="Include Symbols", variable=symbols_var).pack(anchor='w')

# Strength Display
strength_label = tk.Label(root, text="Strength: Weak")
strength_label.pack(pady=10)

# Generate Button
tk.Button(root, text="Generate Password", command=generate_password).pack(pady=20)

root.mainloop()
