
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            event.preventDefault();

            // Here you can collect and use the form data if needed
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            // Notify the user and redirect regardless of input
            alert('Login successful!');

            if (username === validUsername && password === validPassword) {
                alert('Login successful!');
                window.location.href = 'hang.html'; // example redirect}
