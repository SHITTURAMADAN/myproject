print('+++WELCOME TO HANGMAN GAME+++')
print()
while True:
    sporta = 'volleyball'
    sportb = 'football'
    sportc = 'relay race'
    sportd = 'dancing'
    sporte = 'boxing'
    sportf = 'bike race'
    sportg = 'car race'
    sporth = 'basketball'
    sporti = 'ruby'
    sportj = 'hockey'
    hint = 'a sport that you use your hand or leg to play'
    hint_question= input('hello would you like us to give you HINT yes/no')
    if hint_question=='yes':
        print(hint)
    user_guess= input('GUESS ANY KIND OF SPORT YOU KNOW:  ')
    if user_guess==sporta:
        print('GREAT YOU GUESSED RIGHT')
        break
    elif user_guess==sportb:
        break 
        print('GREAT YOU GUESSED RIGHT')
        break
    elif user_guess==sportc:
        print('GREAT YOU GUESSED RIGHT')
        break
    elif user_guess==sportd:
        print('GREAT YOU GUESSED RIGHT')
        break
    elif user_guess==sporte:
        print('GREAT YOU GUESSED RIGHT')
        break
    elif user_guess==sportf:
        print('GREAT YOU GUESSED RIGHT')
        break