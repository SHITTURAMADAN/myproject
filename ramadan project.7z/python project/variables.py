bio_data=input('Enter your name:')

print('my name is',bio_data)
print('my class is',bio_data)