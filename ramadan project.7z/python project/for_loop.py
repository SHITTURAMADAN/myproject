#for loop helps us to go through a list of data and process;
ss1_grade = [50,60,70,54,23,87,88,56]
teachers_bouns=28


for g in ss1_grade:
    print(g+teachers_bouns)
    