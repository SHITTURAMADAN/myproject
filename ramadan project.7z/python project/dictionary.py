user_info={'name':"shittu_ramadan",'age': 16,"learning":'computer_soafware',}
print(user_info)           