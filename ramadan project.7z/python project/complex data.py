# list, tuples, dictionary,sets

#list of word:[] square bracket
words=['farm,school,table,school']

print(words)
print(words)

#list of activities tuples parethesis
my_activities=('running, jogging,sleeping,running')
print(my_activities)

#sets:curly bracket

jobs={'fishing,teaching,fishing,bank manager'}
print (jobs)
