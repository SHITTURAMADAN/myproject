numbers=246810
#print(number)
print('the  number is ',type(numbers))

person_number= int(numbers)

print(person_number)
print('the type of the person number is ',type(numbers))


print(numbers==numbers)