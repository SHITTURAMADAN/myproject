
while True:

    student_grade =  input("enter your grade: ")
    if student_grade == "stop":
        break
    student_grade = int(student_grade)

   

    if student_grade > 100:
        print('wrong grade, try again')
    elif student_grade > 70:
        print('excellent result')

    elif  student_grade >30:
        print('average result')
    elif student_grade <30:
        print('fail')