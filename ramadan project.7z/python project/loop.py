while True:
    password= 123456
    user_password=input('enter your password:  ')
    user_password= int(user_password)
    if user_password == password:
        print('PASSWORD IS CORRECT, LOGIN')
        break
    else:
        print('PASSWORD IS NOT CORRECT, TRY AGAIN')
